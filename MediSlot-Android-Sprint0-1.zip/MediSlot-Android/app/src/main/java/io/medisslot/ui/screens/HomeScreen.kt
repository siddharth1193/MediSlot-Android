package io.medisslot.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

@Composable
fun HomeScreen(nav: NavHostController) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Welcome to MediSlot", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HomeCard("Doctors") { /* TODO */ }
            HomeCard("Hospitals") { /* TODO */ }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HomeCard("Shops") { /* TODO */ }
            HomeCard("Ambulances") { /* TODO */ }
        }
    }
}

@Composable
private fun HomeCard(title: String, onClick: () -> Unit) {
    Card(Modifier.weight(1f).height(100.dp).clickable { onClick() }) {
        Box(Modifier.fillMaxSize().padding(16.dp)) { Text(title) }
    }
}
