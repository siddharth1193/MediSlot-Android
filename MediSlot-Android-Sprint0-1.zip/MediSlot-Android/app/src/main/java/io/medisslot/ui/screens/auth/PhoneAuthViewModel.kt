package io.medisslot.ui.screens.auth

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import io.medisslot.util.Result
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class PhoneAuthViewModel: ViewModel() {
    private val auth = FirebaseAuth.getInstance()

    private val _verificationId = MutableStateFlow<String?>(null)
    val verificationId: StateFlow<String?> = _verificationId

    private val _status = MutableStateFlow<Result<Unit>>(Result.Idle)
    val status: StateFlow<Result<Unit>> = _status

    fun sendOtp(activity: Activity, phone: String) {
        _status.value = Result.Loading

        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                signInWithCredential(credential)
            }
            override fun onVerificationFailed(e: FirebaseException) {
                _status.value = Result.Error(e)
            }
            override fun onCodeSent(
                verificationId: String,
                token: PhoneAuthProvider.ForceResendingToken
            ) {
                _verificationId.value = verificationId
                _status.value = Result.Success(Unit)
            }
        }

        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phone)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)
            .build()

        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    fun verifyOtp(code: String) {
        val vid = verificationId.value ?: return
        val credential = PhoneAuthProvider.getCredential(vid, code)
        signInWithCredential(credential)
    }

    private fun signInWithCredential(credential: PhoneAuthCredential) {
        viewModelScope.launch {
            _status.value = Result.Loading
            auth.signInWithCredential(credential).addOnCompleteListener { task ->
                _status.value =
                    if (task.isSuccessful) Result.Success(Unit)
                    else Result.Error(task.exception ?: Exception("Auth failed"))
            }
        }
    }
}
