package io.medisslot.ui.screens.auth

import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberPermissionState
import io.medisslot.ui.navigation.Dest
import io.medisslot.util.Result

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun PhoneAuthScreen(nav: NavHostController, vm: PhoneAuthViewModel = viewModel()) {
    val ctx = LocalContext.current

    var phone by remember { mutableStateOf("+91") }
    var otp by remember { mutableStateOf("") }

    val status by vm.status.collectAsState()
    val verificationId by vm.verificationId.collectAsState()

    val locPerm = rememberPermissionState(android.Manifest.permission.ACCESS_FINE_LOCATION)

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        if (verificationId == null) {
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Phone") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = { vm.sendOtp(ctx as Activity, phone) },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            ) { Text("Send OTP") }
        } else {
            OutlinedTextField(
                value = otp,
                onValueChange = { otp = it },
                label = { Text("OTP") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = { vm.verifyOtp(otp) },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            ) { Text("Verify") }
        }

        when (status) {
            is Result.Loading -> {
                LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 12.dp))
            }
            is Result.Success -> {
                LaunchedEffect("go-home") {
                    if (!locPerm.status.isGranted) locPerm.launchPermissionRequest()
                    nav.navigate(Dest.Home.route) {
                        popUpTo(Dest.Auth.route) { inclusive = true }
                    }
                }
            }
            is Result.Error -> {
                Text("Error: ${(status as Result.Error).throwable.message}")
            }
            else -> Unit
        }
    }
}
